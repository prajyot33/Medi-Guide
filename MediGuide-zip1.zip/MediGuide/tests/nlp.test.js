import test from "node:test";
import assert from "node:assert/strict";

import { evaluationCases } from "../src/data.js";
import { assessUrgency, classifySymptoms, evaluateClassifier } from "../src/nlp.js";

test("classifier reaches required prototype accuracy on held-out examples", () => {
  const result = evaluateClassifier(evaluationCases);
  assert.equal(result.correct, result.total);
  assert.ok(result.accuracy >= 0.9);
});

test("classifier supports local-language symptom terms", () => {
  assert.equal(classifySymptoms("छाती में दर्द और सांस लेने में तकलीफ").specialtyId, "cardiology");
  assert.equal(classifySymptoms("ಚರ್ಮದ ಮೇಲೆ ದದ್ದು ಮತ್ತು ನೋವು").specialtyId, "dermatology");
  assert.equal(classifySymptoms("கண் வலி மற்றும் மங்கலான பார்வை").specialtyId, "ophthalmology");
  assert.equal(classifySymptoms("చర్మం మీద దద్దుర్లు మరియు దురద").specialtyId, "dermatology");
});

test("urgency scorer escalates red-flag symptoms", () => {
  assert.equal(assessUrgency("chest pain with shortness of breath and sweating").level, "emergency");
  assert.equal(assessUrgency("itching rash on arm for two days").level, "routine");
});
