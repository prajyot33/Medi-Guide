import test from "node:test";
import assert from "node:assert/strict";

import { doctors } from "../src/data.js";
import {
  createAppointment,
  getDoctorQueue,
  markPayment,
  recommendSlots,
  updateAppointmentStatus
} from "../src/scheduler.js";
import { classifySymptoms } from "../src/nlp.js";

const baseDate = new Date("2026-06-08T08:00:00+05:30");

test("scheduler recommends matching specialty before unrelated doctors", () => {
  const slots = recommendSlots({
    specialtyId: "cardiology",
    urgencyLevel: "urgent",
    doctors,
    appointments: [],
    now: baseDate
  });
  assert.equal(slots[0].specialtyId, "cardiology");
});

test("scheduler does not offer already booked slots", () => {
  const triage = classifySymptoms("chest pain and sweating");
  const [slot] = recommendSlots({
    specialtyId: triage.specialtyId,
    urgencyLevel: triage.urgency.level,
    doctors,
    appointments: [],
    now: baseDate
  });
  const appointment = createAppointment({
    patient: { name: "Test Patient", age: 40, phone: "12345", symptoms: "chest pain and sweating" },
    triage,
    slot
  });
  const nextSlots = recommendSlots({
    specialtyId: triage.specialtyId,
    urgencyLevel: triage.urgency.level,
    doctors,
    appointments: [appointment],
    now: baseDate
  });
  assert.notEqual(nextSlots[0].id, slot.id);
});

test("doctor queue prioritizes urgent cases and estimates waiting time", () => {
  const routineTriage = classifySymptoms("itchy rash on arm");
  const urgentTriage = classifySymptoms("chest pain and shortness of breath");
  const doctorSlot = {
    doctorId: "doc-cardio-rao",
    doctorName: "Dr. Meera Rao",
    specialtyId: "cardiology",
    startsAt: "2026-06-08T09:00:00.000Z",
    consultationMinutes: 18
  };
  const routine = createAppointment({
    patient: { name: "Routine Patient", age: 30, phone: "1", symptoms: "itchy rash on arm" },
    triage: { ...routineTriage, specialtyId: "cardiology", specialtyName: "Cardiology" },
    slot: doctorSlot
  });
  const urgent = createAppointment({
    patient: { name: "Urgent Patient", age: 55, phone: "2", symptoms: "chest pain and shortness of breath" },
    triage: urgentTriage,
    slot: { ...doctorSlot, startsAt: "2026-06-08T09:30:00.000Z" }
  });

  const queue = getDoctorQueue("doc-cardio-rao", [routine, urgent], baseDate);
  assert.equal(queue[0].patientName, "Urgent Patient");
  assert.equal(queue[1].estimatedWaitMinutes, 18);
});

test("payment and status helpers update appointment lifecycle", () => {
  const triage = classifySymptoms("child fever and fast breathing");
  const [slot] = recommendSlots({
    specialtyId: triage.specialtyId,
    urgencyLevel: triage.urgency.level,
    doctors,
    appointments: [],
    now: baseDate
  });
  const appointment = createAppointment({
    patient: { name: "Kid", age: 8, phone: "123", symptoms: "child fever and fast breathing" },
    triage,
    slot
  });
  const paid = markPayment(appointment, "Mock Card", baseDate);
  const completed = updateAppointmentStatus(updateAppointmentStatus(paid, "in-progress", baseDate), "completed", new Date(baseDate.getTime() + 15 * 60000));

  assert.equal(paid.paymentStatus, "paid");
  assert.equal(completed.status, "completed");
  assert.ok(completed.startedAt);
  assert.ok(completed.completedAt);
});
