export const specialties = [
  {
    id: "general-medicine",
    name: "General Medicine",
    description: "First-line assessment for fever, fatigue, nonspecific pain, and unclear symptoms."
  },
  {
    id: "cardiology",
    name: "Cardiology",
    description: "Heart and circulation symptoms such as chest pain, palpitations, fainting, and breathlessness."
  },
  {
    id: "dermatology",
    name: "Dermatology",
    description: "Skin, hair, and nail problems such as rashes, acne, itching, and infections."
  },
  {
    id: "orthopedics",
    name: "Orthopedics",
    description: "Bone, joint, muscle, fracture, sprain, and mobility concerns."
  },
  {
    id: "neurology",
    name: "Neurology",
    description: "Brain, nerve, seizure, migraine, weakness, numbness, and stroke-like symptoms."
  },
  {
    id: "pulmonology",
    name: "Pulmonology",
    description: "Breathing, cough, asthma, wheezing, and lung-related symptoms."
  },
  {
    id: "gastroenterology",
    name: "Gastroenterology",
    description: "Stomach, liver, digestion, vomiting, diarrhea, acidity, and abdominal pain."
  },
  {
    id: "ent",
    name: "ENT",
    description: "Ear, nose, throat, sinus, tonsil, voice, and hearing symptoms."
  },
  {
    id: "ophthalmology",
    name: "Ophthalmology",
    description: "Eye pain, redness, vision changes, and eye injuries."
  },
  {
    id: "pediatrics",
    name: "Pediatrics",
    description: "Medical care for infants, children, and adolescents."
  },
  {
    id: "psychiatry",
    name: "Psychiatry",
    description: "Mental health symptoms such as anxiety, panic, depression, and sleep disturbance."
  },
  {
    id: "gynecology",
    name: "Gynecology",
    description: "Pregnancy, menstrual, reproductive, pelvic, and women's health concerns."
  }
];

export const specialtyKeywords = {
  "general-medicine": {
    fever: 2,
    fatigue: 2,
    weakness: 1,
    bodyache: 2,
    infection: 1,
    dizziness: 1,
    chills: 2,
    "high temperature": 2,
    viral: 2,
    malaria: 2,
    dengue: 2,
    "blood pressure": 1
  },
  cardiology: {
    "chest pain": 5,
    chest: 2,
    heart: 3,
    palpitation: 4,
    palpitations: 4,
    "irregular heartbeat": 5,
    "shortness of breath": 4,
    breathlessness: 4,
    sweating: 3,
    fainting: 3,
    syncope: 3,
    "left arm pain": 4,
    "jaw pain": 3,
    pressure: 2
  },
  dermatology: {
    rash: 5,
    skin: 4,
    itching: 4,
    itchy: 4,
    acne: 4,
    pimple: 3,
    eczema: 5,
    psoriasis: 5,
    mole: 3,
    blister: 3,
    hives: 4,
    "hair fall": 3,
    nail: 2
  },
  orthopedics: {
    fracture: 5,
    sprain: 4,
    "joint pain": 4,
    joint: 3,
    knee: 4,
    shoulder: 4,
    ankle: 4,
    back: 3,
    spine: 4,
    bone: 4,
    swelling: 2,
    "cannot move": 4,
    "sports injury": 4,
    fall: 3
  },
  neurology: {
    seizure: 6,
    convulsion: 5,
    migraine: 5,
    headache: 3,
    numbness: 4,
    weakness: 2,
    paralysis: 6,
    stroke: 6,
    "slurred speech": 5,
    confusion: 4,
    tremor: 4,
    vertigo: 3,
    "loss of consciousness": 5
  },
  pulmonology: {
    cough: 4,
    wheezing: 5,
    asthma: 5,
    breathing: 3,
    breathlessness: 3,
    "shortness of breath": 3,
    sputum: 3,
    pneumonia: 5,
    tuberculosis: 5,
    "chest tightness": 3,
    "fast breathing": 4
  },
  gastroenterology: {
    stomach: 4,
    abdominal: 4,
    abdomen: 4,
    vomiting: 4,
    nausea: 3,
    diarrhea: 5,
    diarrhoea: 5,
    constipation: 3,
    acidity: 3,
    reflux: 3,
    liver: 4,
    jaundice: 5,
    "blood in stool": 5,
    "loose motion": 4
  },
  ent: {
    ear: 4,
    throat: 4,
    tonsil: 4,
    sinus: 4,
    sneezing: 3,
    nose: 3,
    hearing: 4,
    "sore throat": 4,
    "runny nose": 2,
    hoarse: 3,
    vertigo: 2
  },
  ophthalmology: {
    eye: 4,
    vision: 5,
    "blurred vision": 5,
    "blurry vision": 5,
    redness: 3,
    "eye pain": 5,
    "double vision": 5,
    cataract: 4,
    glaucoma: 5,
    "foreign body": 4,
    "watery eyes": 3
  },
  pediatrics: {
    child: 5,
    baby: 5,
    infant: 5,
    toddler: 5,
    newborn: 5,
    kid: 4,
    vaccination: 4,
    "fast breathing": 3,
    "not feeding": 5,
    "school age": 3
  },
  psychiatry: {
    anxiety: 5,
    panic: 5,
    depression: 5,
    depressed: 4,
    insomnia: 4,
    sleep: 3,
    stress: 3,
    "mood swing": 4,
    hallucination: 5,
    suicidal: 7,
    selfharm: 7,
    "self harm": 7
  },
  gynecology: {
    pregnancy: 5,
    pregnant: 5,
    period: 4,
    menstrual: 4,
    bleeding: 3,
    pelvic: 4,
    "pelvic pain": 5,
    "vaginal discharge": 5,
    menopause: 3,
    infertility: 4,
    contraception: 4,
    "missed period": 4
  }
};

export const urgentSignals = [
  { phrase: "chest pain", score: 4, reason: "Chest pain can need urgent cardiac assessment." },
  { phrase: "shortness of breath", score: 4, reason: "Breathing difficulty increases urgency." },
  { phrase: "breathlessness", score: 4, reason: "Breathlessness increases urgency." },
  { phrase: "severe pain", score: 3, reason: "Severe pain should be prioritized." },
  { phrase: "high fever", score: 3, reason: "High fever may need prompt evaluation." },
  { phrase: "fainting", score: 4, reason: "Fainting can indicate serious underlying illness." },
  { phrase: "loss of consciousness", score: 5, reason: "Loss of consciousness needs urgent review." },
  { phrase: "seizure", score: 5, reason: "Seizures are high-priority neurological symptoms." },
  { phrase: "stroke", score: 6, reason: "Stroke-like symptoms are emergency signs." },
  { phrase: "slurred speech", score: 5, reason: "Slurred speech can be a stroke warning sign." },
  { phrase: "paralysis", score: 5, reason: "Paralysis or sudden weakness needs immediate assessment." },
  { phrase: "blood in stool", score: 4, reason: "Bleeding symptoms should be prioritized." },
  { phrase: "suicidal", score: 6, reason: "Self-harm risk is an emergency mental-health concern." },
  { phrase: "self harm", score: 6, reason: "Self-harm risk is an emergency mental-health concern." },
  { phrase: "not feeding", score: 4, reason: "Infants not feeding need rapid pediatric review." },
  { phrase: "pregnant bleeding", score: 5, reason: "Bleeding during pregnancy needs urgent care." }
];

export const doctors = [
  {
    id: "doc-cardio-rao",
    name: "Dr. Meera Rao",
    specialtyId: "cardiology",
    rating: 4.9,
    qualityScore: 96,
    consultationMinutes: 18,
    languages: ["English", "Hindi", "Kannada"],
    weeklySlots: ["09:00", "09:30", "10:00", "14:30", "15:00"]
  },
  {
    id: "doc-cardio-sen",
    name: "Dr. Arjun Sen",
    specialtyId: "cardiology",
    rating: 4.7,
    qualityScore: 91,
    consultationMinutes: 20,
    languages: ["English", "Hindi"],
    weeklySlots: ["11:00", "11:30", "16:00", "16:30"]
  },
  {
    id: "doc-derm-kulkarni",
    name: "Dr. Nisha Kulkarni",
    specialtyId: "dermatology",
    rating: 4.8,
    qualityScore: 94,
    consultationMinutes: 14,
    languages: ["English", "Kannada"],
    weeklySlots: ["10:00", "10:20", "12:00", "15:20", "17:00"]
  },
  {
    id: "doc-ortho-menon",
    name: "Dr. Vivek Menon",
    specialtyId: "orthopedics",
    rating: 4.6,
    qualityScore: 90,
    consultationMinutes: 16,
    languages: ["English", "Malayalam", "Hindi"],
    weeklySlots: ["09:40", "10:20", "13:40", "16:20"]
  },
  {
    id: "doc-neuro-iyer",
    name: "Dr. Kavya Iyer",
    specialtyId: "neurology",
    rating: 4.9,
    qualityScore: 97,
    consultationMinutes: 22,
    languages: ["English", "Tamil", "Hindi"],
    weeklySlots: ["09:30", "12:30", "15:00", "17:30"]
  },
  {
    id: "doc-pulm-shah",
    name: "Dr. Farah Shah",
    specialtyId: "pulmonology",
    rating: 4.7,
    qualityScore: 92,
    consultationMinutes: 17,
    languages: ["English", "Hindi", "Urdu"],
    weeklySlots: ["09:10", "10:40", "14:10", "16:40"]
  },
  {
    id: "doc-gastro-nair",
    name: "Dr. Thomas Nair",
    specialtyId: "gastroenterology",
    rating: 4.6,
    qualityScore: 89,
    consultationMinutes: 16,
    languages: ["English", "Malayalam"],
    weeklySlots: ["10:30", "11:10", "15:30", "17:10"]
  },
  {
    id: "doc-ent-hegde",
    name: "Dr. Ritu Hegde",
    specialtyId: "ent",
    rating: 4.5,
    qualityScore: 88,
    consultationMinutes: 13,
    languages: ["English", "Kannada", "Hindi"],
    weeklySlots: ["09:20", "10:50", "14:50", "16:10"]
  },
  {
    id: "doc-eye-bose",
    name: "Dr. Anita Bose",
    specialtyId: "ophthalmology",
    rating: 4.8,
    qualityScore: 93,
    consultationMinutes: 15,
    languages: ["English", "Bengali", "Hindi"],
    weeklySlots: ["09:50", "11:20", "15:50", "17:20"]
  },
  {
    id: "doc-peds-reddy",
    name: "Dr. Sai Reddy",
    specialtyId: "pediatrics",
    rating: 4.9,
    qualityScore: 98,
    consultationMinutes: 18,
    languages: ["English", "Telugu", "Hindi"],
    weeklySlots: ["09:00", "10:30", "13:30", "16:00"]
  },
  {
    id: "doc-psych-joshi",
    name: "Dr. Leela Joshi",
    specialtyId: "psychiatry",
    rating: 4.8,
    qualityScore: 95,
    consultationMinutes: 30,
    languages: ["English", "Hindi", "Marathi"],
    weeklySlots: ["11:00", "12:00", "15:00", "18:00"]
  },
  {
    id: "doc-gyn-murthy",
    name: "Dr. Priya Murthy",
    specialtyId: "gynecology",
    rating: 4.7,
    qualityScore: 92,
    consultationMinutes: 20,
    languages: ["English", "Kannada", "Hindi"],
    weeklySlots: ["09:30", "11:30", "14:30", "16:30"]
  },
  {
    id: "doc-gen-khan",
    name: "Dr. Sameer Khan",
    specialtyId: "general-medicine",
    rating: 4.6,
    qualityScore: 90,
    consultationMinutes: 15,
    languages: ["English", "Hindi"],
    weeklySlots: ["09:00", "09:45", "12:15", "15:45", "18:15"]
  }
];

export const evaluationCases = [
  { text: "Crushing chest pain with sweating and shortness of breath", expected: "cardiology" },
  { text: "Itchy red rash and small blisters on my arm", expected: "dermatology" },
  { text: "Knee swelling after a fall and I cannot bend it", expected: "orthopedics" },
  { text: "Migraine headache with numbness in one hand", expected: "neurology" },
  { text: "Wheezing cough and asthma attack since morning", expected: "pulmonology" },
  { text: "Severe stomach pain with vomiting and loose motion", expected: "gastroenterology" },
  { text: "Ear pain with sore throat and sinus congestion", expected: "ent" },
  { text: "Eye redness and blurry vision after an injury", expected: "ophthalmology" },
  { text: "My baby has fever and is not feeding well", expected: "pediatrics" },
  { text: "Panic attacks, anxiety, and poor sleep", expected: "psychiatry" },
  { text: "Missed period, pelvic pain, and pregnancy concern", expected: "gynecology" },
  { text: "Fever, chills, bodyache and fatigue for three days", expected: "general-medicine" },
  { text: "छाती में दर्द और सांस लेने में तकलीफ", expected: "cardiology" },
  { text: "ಜ್ವರ ಮತ್ತು ಕೆಮ್ಮು ಇರುವ ಮಗು", expected: "pediatrics" },
  { text: "கண் வலி மற்றும் மங்கலான பார்வை", expected: "ophthalmology" },
  { text: "చర్మం మీద దద్దుర్లు మరియు దురద", expected: "dermatology" }
];
