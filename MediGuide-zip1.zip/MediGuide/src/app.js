import { doctors, evaluationCases, specialties } from "./data.js";
import { classifySymptoms, evaluateClassifier } from "./nlp.js";
import {
  createAppointment,
  formatDateTime,
  getDoctorMetrics,
  getDoctorQueue,
  getSpecialtyName,
  markPayment,
  recommendSlots,
  updateAppointmentStatus
} from "./scheduler.js";
import { createVoiceInput, isVoiceSupported } from "./voice.js";
import { loadState, resetState, saveState } from "./store.js";

const state = loadState();
let activeView = "patient";
let selectedDoctorId = doctors[0].id;
let latestTriage = null;
let latestSlots = [];

const elements = {
  chatLog: document.querySelector("#chat-log"),
  symptomForm: document.querySelector("#symptom-form"),
  symptomInput: document.querySelector("#symptom-input"),
  voiceButton: document.querySelector("#voice-button"),
  voiceLanguage: document.querySelector("#voice-language"),
  triageResult: document.querySelector("#triage-result"),
  slotSelect: document.querySelector("#slot-select"),
  bookingForm: document.querySelector("#booking-form"),
  bookButton: document.querySelector("#book-button"),
  patientName: document.querySelector("#patient-name"),
  patientAge: document.querySelector("#patient-age"),
  patientPhone: document.querySelector("#patient-phone"),
  patientAppointments: document.querySelector("#patient-appointments"),
  doctorSelect: document.querySelector("#doctor-select"),
  doctorProfile: document.querySelector("#doctor-profile"),
  doctorMetrics: document.querySelector("#doctor-metrics"),
  doctorQueue: document.querySelector("#doctor-queue"),
  slotForm: document.querySelector("#slot-form"),
  newSlotTime: document.querySelector("#new-slot-time"),
  refreshQueue: document.querySelector("#refresh-queue"),
  clearDemo: document.querySelector("#clear-demo"),
  evaluationSummary: document.querySelector("#evaluation-summary"),
  evaluationTable: document.querySelector("#evaluation-table"),
  toastRegion: document.querySelector("#toast-region")
};

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function percent(value) {
  return `${Math.round(value * 100)}%`;
}

function showToast(message) {
  const toast = document.createElement("div");
  toast.className = "toast";
  toast.textContent = message;
  elements.toastRegion.append(toast);
  setTimeout(() => toast.remove(), 4200);
}

function saveAndRender() {
  saveState(state);
  renderAppointments();
  renderDoctorPortal();
}

function statusClass(status) {
  return `status-${String(status).replace(/\s+/g, "-")}`;
}

function urgencyBadgeClass(level) {
  if (level === "emergency") return "badge emergency";
  if (level === "urgent") return "badge urgent";
  return "badge";
}

function setView(viewName) {
  activeView = viewName;
  document.querySelectorAll(".tab-button").forEach((button) => {
    button.classList.toggle("is-active", button.dataset.view === viewName);
  });
  document.querySelectorAll(".view-panel").forEach((panel) => {
    panel.classList.toggle("is-active", panel.id === `${viewName}-view`);
  });
  if (viewName === "doctor") {
    renderDoctorPortal();
  }
  if (viewName === "evaluation") {
    renderEvaluation();
  }
}

function addMessage(role, body) {
  const message = document.createElement("div");
  message.className = `message ${role}`;
  message.innerHTML = body;
  elements.chatLog.append(message);
  elements.chatLog.scrollTop = elements.chatLog.scrollHeight;
}

function renderIntroMessage() {
  addMessage(
    "bot",
    "<strong>Hello, I am MediGuide.</strong>Tell me the main symptoms, duration, and age group. I will recommend a department and show appointment slots."
  );
}

function renderSlots(slots) {
  elements.slotSelect.innerHTML = "";
  if (!slots.length) {
    elements.slotSelect.innerHTML = '<option value="">No slots available</option>';
    elements.bookButton.disabled = true;
    return;
  }

  slots.forEach((slot, index) => {
    const option = document.createElement("option");
    option.value = String(index);
    option.textContent = `${slot.doctorName} - ${formatDateTime(slot.startsAt)} - ${slot.rating.toFixed(1)} star`;
    elements.slotSelect.append(option);
  });
  elements.bookButton.disabled = false;
}

function renderTriage(triage) {
  const alternatives = triage.alternatives
    .filter((item) => item.score > 0)
    .map((item) => `<span class="badge">${escapeHtml(item.specialtyName)} ${Math.round(item.score)}</span>`)
    .join("");
  const terms = triage.matchedTerms.length
    ? triage.matchedTerms.map((term) => `<span class="badge">${escapeHtml(term)}</span>`).join("")
    : '<span class="badge">fallback triage</span>';
  const reasons = [
    ...triage.urgency.reasons,
    `Matched ${triage.matchedTerms.length || "no exact"} symptom signal${triage.matchedTerms.length === 1 ? "" : "s"}.`
  ];

  elements.triageResult.innerHTML = `
    <article class="recommendation-card">
      <div class="recommendation-top">
        <div>
          <div class="specialty-name">${escapeHtml(triage.specialtyName)}</div>
          <p class="confidence">${escapeHtml(triage.description)}</p>
        </div>
        <span class="${urgencyBadgeClass(triage.urgency.level)}">${escapeHtml(triage.urgency.label)}</span>
      </div>
      <div class="badge-row">
        <span class="badge">Confidence ${percent(triage.confidence)}</span>
        ${terms}
      </div>
      <ol class="explain-list">
        ${reasons.map((reason) => `<li>${escapeHtml(reason)}</li>`).join("")}
        <li>${escapeHtml(triage.urgency.recommendation)}</li>
      </ol>
      ${alternatives ? `<div class="badge-row" aria-label="Alternatives">${alternatives}</div>` : ""}
    </article>
  `;
}

function refreshLatestSlots() {
  if (!latestTriage) {
    return;
  }
  latestSlots = recommendSlots({
    specialtyId: latestTriage.specialtyId,
    urgencyLevel: latestTriage.urgency.level,
    doctors,
    appointments: state.appointments,
    manualSlots: state.manualSlots
  });
  renderSlots(latestSlots);
}

function analyzeSymptoms(text) {
  latestTriage = classifySymptoms(text);
  refreshLatestSlots();
  renderTriage(latestTriage);
  addMessage("user", escapeHtml(text));
  addMessage(
    "bot",
    `<strong>${escapeHtml(latestTriage.specialtyName)} recommended.</strong>${escapeHtml(
      latestTriage.urgency.recommendation
    )} I found ${latestSlots.length} suitable slot${latestSlots.length === 1 ? "" : "s"}.`
  );
}

function appointmentMeta(appointment, queueItem) {
  const waitText = queueItem
    ? `${queueItem.estimatedWaitMinutes} min`
    : appointment.status === "completed"
      ? "Completed"
      : appointment.status === "cancelled"
        ? "Cancelled"
        : "On schedule";

  return [
    ["Doctor", appointment.doctorName],
    ["When", formatDateTime(appointment.startsAt)],
    ["Urgency", appointment.urgencyLabel],
    ["Wait", waitText]
  ];
}

function renderAppointmentCard(appointment) {
  const queueItem = getDoctorQueue(appointment.doctorId, state.appointments).find((item) => item.id === appointment.id);
  const canPay = appointment.paymentStatus !== "paid" && !["cancelled", "no-show"].includes(appointment.status);
  const canCancel = !["cancelled", "completed", "no-show"].includes(appointment.status);
  const meta = appointmentMeta(appointment, queueItem)
    .map(
      ([label, value]) => `
        <div class="meta-item">
          <span class="meta-label">${escapeHtml(label)}</span>
          <span class="meta-value">${escapeHtml(value)}</span>
        </div>
      `
    )
    .join("");

  return `
    <article class="appointment-card" data-appointment-id="${escapeHtml(appointment.id)}">
      <header>
        <div>
          <h3>${escapeHtml(appointment.patientName)} - ${escapeHtml(appointment.specialtyName)}</h3>
          <p class="confidence">${escapeHtml(appointment.symptoms)}</p>
        </div>
        <span class="status-pill ${statusClass(appointment.status)}">${escapeHtml(appointment.status)}</span>
      </header>
      <div class="meta-grid">${meta}</div>
      <div class="badge-row">
        <span class="badge">${escapeHtml(appointment.paymentStatus === "paid" ? "Payment paid" : "Payment pending")}</span>
        <span class="${urgencyBadgeClass(appointment.urgencyLevel)}">${escapeHtml(appointment.urgencyLevel)}</span>
        <span class="badge">AI confidence ${percent(appointment.confidence)}</span>
      </div>
      <div class="card-actions">
        ${
          canPay
            ? `<button class="payment-button" type="button" data-action="pay" data-id="${escapeHtml(appointment.id)}">Pay now</button>`
            : ""
        }
        ${
          canCancel
            ? `<button class="danger-action" type="button" data-action="cancel" data-id="${escapeHtml(appointment.id)}">Cancel appointment</button>`
            : ""
        }
      </div>
    </article>
  `;
}

function renderAppointments() {
  const appointments = [...state.appointments].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  if (!appointments.length) {
    elements.patientAppointments.innerHTML = '<p class="empty-state">No appointments yet. Analyze symptoms and book a recommended slot.</p>';
    return;
  }

  elements.patientAppointments.innerHTML = appointments.map(renderAppointmentCard).join("");
}

function renderDoctorOptions() {
  elements.doctorSelect.innerHTML = doctors
    .map((doctor) => `<option value="${escapeHtml(doctor.id)}">${escapeHtml(doctor.name)} - ${escapeHtml(getSpecialtyName(doctor.specialtyId))}</option>`)
    .join("");
  elements.doctorSelect.value = selectedDoctorId;
}

function renderDoctorProfile(doctor) {
  elements.doctorProfile.innerHTML = `
    <h3>${escapeHtml(doctor.name)}</h3>
    <p>${escapeHtml(getSpecialtyName(doctor.specialtyId))}</p>
    <div class="badge-row">
      <span class="badge">${doctor.rating.toFixed(1)} star rating</span>
      <span class="badge">Quality ${doctor.qualityScore}</span>
      <span class="badge">${doctor.consultationMinutes} min consult</span>
    </div>
    <p class="confidence">Languages: ${escapeHtml(doctor.languages.join(", "))}</p>
  `;
}

function renderDoctorMetrics(doctorId) {
  const metrics = getDoctorMetrics(doctorId, state.appointments);
  const items = [
    ["Queue", metrics.queueCount],
    ["Urgent", metrics.urgentCount],
    ["Paid", metrics.paidCount],
    ["Avg consult", metrics.averageConsultMinutes ? `${metrics.averageConsultMinutes}m` : "-"]
  ];

  elements.doctorMetrics.innerHTML = items
    .map(
      ([label, value]) => `
        <div class="metric">
          <strong>${escapeHtml(value)}</strong>
          <span>${escapeHtml(label)}</span>
        </div>
      `
    )
    .join("");
}

function renderQueueCard(appointment) {
  const paymentBadge = appointment.paymentStatus === "paid" ? "Payment paid" : "Payment pending";
  const canStart = appointment.status === "booked";
  const canFinish = appointment.status === "in-progress";

  return `
    <article class="queue-card" data-appointment-id="${escapeHtml(appointment.id)}">
      <header>
        <div>
          <h3>#${appointment.queuePosition} ${escapeHtml(appointment.patientName)}</h3>
          <p class="confidence">${escapeHtml(appointment.symptoms)}</p>
        </div>
        <span class="status-pill ${statusClass(appointment.status)}">${escapeHtml(appointment.status)}</span>
      </header>
      <div class="meta-grid">
        <div class="meta-item">
          <span class="meta-label">Slot</span>
          <span class="meta-value">${escapeHtml(formatDateTime(appointment.startsAt))}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Wait</span>
          <span class="meta-value">${appointment.estimatedWaitMinutes} min</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Specialty</span>
          <span class="meta-value">${escapeHtml(appointment.specialtyName)}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Payment</span>
          <span class="meta-value">${escapeHtml(paymentBadge)}</span>
        </div>
      </div>
      <div class="badge-row">
        <span class="${urgencyBadgeClass(appointment.urgencyLevel)}">${escapeHtml(appointment.urgencyLabel)}</span>
        <span class="badge">ETA ${escapeHtml(formatDateTime(appointment.estimatedStartAt))}</span>
      </div>
      <div class="queue-actions">
        ${canStart ? `<button class="primary-action" type="button" data-action="start" data-id="${escapeHtml(appointment.id)}">Start consult</button>` : ""}
        ${canFinish ? `<button class="primary-action" type="button" data-action="complete" data-id="${escapeHtml(appointment.id)}">Finish consult</button>` : ""}
        <button type="button" data-action="noshow" data-id="${escapeHtml(appointment.id)}">No-show</button>
        <button class="danger-action" type="button" data-action="cancel" data-id="${escapeHtml(appointment.id)}">Cancel</button>
      </div>
    </article>
  `;
}

function renderDoctorPortal() {
  const doctor = doctors.find((item) => item.id === selectedDoctorId) || doctors[0];
  selectedDoctorId = doctor.id;
  elements.doctorSelect.value = selectedDoctorId;
  renderDoctorProfile(doctor);
  renderDoctorMetrics(doctor.id);

  const queue = getDoctorQueue(doctor.id, state.appointments);
  elements.doctorQueue.innerHTML = queue.length
    ? queue.map(renderQueueCard).join("")
    : '<p class="empty-state">No active patients in this queue. Add a slot or book from the patient tab.</p>';
}

function renderEvaluation() {
  const evaluation = evaluateClassifier(evaluationCases);
  const items = [
    ["Accuracy", percent(evaluation.accuracy)],
    ["Correct", evaluation.correct],
    ["Cases", evaluation.total],
    ["Avg confidence", percent(evaluation.rows.reduce((sum, row) => sum + row.confidence, 0) / evaluation.total)]
  ];

  elements.evaluationSummary.innerHTML = items
    .map(
      ([label, value]) => `
        <div class="metric">
          <strong>${escapeHtml(value)}</strong>
          <span>${escapeHtml(label)}</span>
        </div>
      `
    )
    .join("");

  elements.evaluationTable.innerHTML = `
    <table>
      <thead>
        <tr>
          <th>Query</th>
          <th>Expected</th>
          <th>Predicted</th>
          <th>Confidence</th>
          <th>Result</th>
        </tr>
      </thead>
      <tbody>
        ${evaluation.rows
          .map(
            (row) => `
              <tr>
                <td>${escapeHtml(row.text)}</td>
                <td>${escapeHtml(row.expected)}</td>
                <td>${escapeHtml(row.predicted)}</td>
                <td>${percent(row.confidence)}</td>
                <td>${row.passed ? "Pass" : "Review"}</td>
              </tr>
            `
          )
          .join("")}
      </tbody>
    </table>
  `;
}

function updateAppointment(id, updater) {
  const index = state.appointments.findIndex((appointment) => appointment.id === id);
  if (index === -1) {
    return;
  }
  state.appointments[index] = updater(state.appointments[index]);
  saveAndRender();
}

function handleBookingSubmit(event) {
  event.preventDefault();
  if (!latestTriage) {
    showToast("Analyze symptoms before booking.");
    return;
  }

  const slot = latestSlots[Number(elements.slotSelect.value)];
  if (!slot) {
    showToast("Choose an available slot.");
    return;
  }

  const appointment = createAppointment({
    patient: {
      name: elements.patientName.value,
      age: elements.patientAge.value,
      phone: elements.patientPhone.value,
      symptoms: elements.symptomInput.value
    },
    triage: latestTriage,
    slot
  });

  state.appointments.push(appointment);
  saveAndRender();
  refreshLatestSlots();
  showToast(`Appointment booked with ${slot.doctorName}.`);
}

function handlePatientActions(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  const { action, id } = button.dataset;
  if (action === "pay") {
    updateAppointment(id, (appointment) => markPayment(appointment, "Mock UPI/Card"));
    showToast("Mock payment confirmed and linked to the appointment.");
  }
  if (action === "cancel") {
    updateAppointment(id, (appointment) => updateAppointmentStatus(appointment, "cancelled"));
    refreshLatestSlots();
    showToast("Appointment cancelled. The slot is released for new bookings.");
  }
}

function handleDoctorActions(event) {
  const button = event.target.closest("button[data-action]");
  if (!button) return;

  const { action, id } = button.dataset;
  const statusByAction = {
    start: "in-progress",
    complete: "completed",
    noshow: "no-show",
    cancel: "cancelled"
  };
  const status = statusByAction[action];
  if (!status) return;

  updateAppointment(id, (appointment) => updateAppointmentStatus(appointment, status));
  showToast(`Appointment marked ${status}.`);
}

function setDefaultDateTimeMin() {
  const now = new Date(Date.now() + 30 * 60 * 1000);
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
  elements.newSlotTime.min = local;
  elements.newSlotTime.value = local;
}

function addManualSlot(event) {
  event.preventDefault();
  const startsAt = new Date(elements.newSlotTime.value);
  if (Number.isNaN(startsAt.getTime()) || startsAt <= new Date()) {
    showToast("Choose a future slot time.");
    return;
  }

  state.manualSlots.push({
    id: `manual-${selectedDoctorId}-${startsAt.toISOString()}`,
    doctorId: selectedDoctorId,
    startsAt: startsAt.toISOString()
  });
  saveAndRender();
  setDefaultDateTimeMin();
  refreshLatestSlots();
  showToast("New doctor slot added.");
}

function seedDemoData() {
  resetState();
  state.appointments = [];
  state.manualSlots = [];
  const seedInputs = [
    {
      patient: { name: "Asha Kumar", age: 44, phone: "+91 90000 11111", symptoms: "Chest pain and sweating" },
      triage: classifySymptoms("Chest pain and sweating"),
      slot: recommendSlots({ specialtyId: "cardiology", urgencyLevel: "urgent", doctors, appointments: [] })[0],
      paid: true
    },
    {
      patient: { name: "Rohan Pai", age: 8, phone: "+91 90000 22222", symptoms: "Child fever and fast breathing" },
      triage: classifySymptoms("Child fever and fast breathing"),
      slot: recommendSlots({ specialtyId: "pediatrics", urgencyLevel: "urgent", doctors, appointments: [] })[0],
      paid: false
    },
    {
      patient: { name: "Meena Das", age: 31, phone: "+91 90000 33333", symptoms: "Itchy rash on hand" },
      triage: classifySymptoms("Itchy rash on hand"),
      slot: recommendSlots({ specialtyId: "dermatology", urgencyLevel: "routine", doctors, appointments: [] })[0],
      paid: true
    }
  ];

  for (const item of seedInputs) {
    if (!item.slot) continue;
    let appointment = createAppointment(item);
    if (item.paid) {
      appointment = markPayment(appointment, "Mock UPI");
    }
    state.appointments.push(appointment);
  }
  saveAndRender();
  showToast("Demo data reset.");
}

function bindEvents() {
  document.querySelectorAll(".tab-button").forEach((button) => {
    button.addEventListener("click", () => setView(button.dataset.view));
  });

  elements.symptomForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const text = elements.symptomInput.value.trim();
    if (!text) {
      showToast("Enter symptoms before analysis.");
      return;
    }
    analyzeSymptoms(text);
  });

  document.querySelectorAll("[data-sample]").forEach((button) => {
    button.addEventListener("click", () => {
      elements.symptomInput.value = button.dataset.sample;
      analyzeSymptoms(button.dataset.sample);
    });
  });

  elements.bookingForm.addEventListener("submit", handleBookingSubmit);
  elements.patientAppointments.addEventListener("click", handlePatientActions);
  elements.doctorQueue.addEventListener("click", handleDoctorActions);
  elements.slotForm.addEventListener("submit", addManualSlot);
  elements.refreshQueue.addEventListener("click", () => {
    renderDoctorPortal();
    showToast("Queue refreshed.");
  });
  elements.clearDemo.addEventListener("click", seedDemoData);
  elements.doctorSelect.addEventListener("change", () => {
    selectedDoctorId = elements.doctorSelect.value;
    renderDoctorPortal();
  });
}

function bindVoice() {
  const voiceInput = createVoiceInput({
    language: elements.voiceLanguage.value,
    onResult(transcript) {
      elements.symptomInput.value = transcript;
      analyzeSymptoms(transcript);
    },
    onError(message) {
      showToast(message);
    },
    onStateChange(stateName) {
      elements.voiceButton.classList.toggle("is-listening", stateName === "listening");
      elements.voiceButton.title = stateName === "listening" ? "Listening" : "Start voice input";
    }
  });

  if (!isVoiceSupported()) {
    elements.voiceButton.title = "Voice input unavailable";
  }

  elements.voiceButton.addEventListener("click", () => {
    voiceInput.start(elements.voiceLanguage.value);
  });
}

function boot() {
  renderIntroMessage();
  renderDoctorOptions();
  renderAppointments();
  renderDoctorPortal();
  renderEvaluation();
  setDefaultDateTimeMin();
  bindEvents();
  bindVoice();
  setInterval(() => {
    if (activeView === "doctor") {
      renderDoctorPortal();
    }
    renderAppointments();
  }, 30000);
}

boot();
