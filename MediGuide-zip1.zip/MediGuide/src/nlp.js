import { specialties, specialtyKeywords, urgentSignals } from "./data.js";

const fillerWords = new Set([
  "a",
  "an",
  "and",
  "are",
  "for",
  "from",
  "have",
  "having",
  "i",
  "in",
  "is",
  "it",
  "me",
  "my",
  "of",
  "on",
  "or",
  "since",
  "the",
  "to",
  "with"
]);

const localLanguageTerms = [
  ["bukhar", "fever"],
  ["khansi", "cough"],
  ["saans", "breathing"],
  ["dard", "pain"],
  ["pet", "stomach"],
  ["sir", "headache"],
  ["chakkar", "dizziness"],
  ["daane", "rash"],
  ["jalan", "burning"],
  ["bachcha", "child"],
  ["bacha", "child"],
  ["bukhar hai", "fever"],
  ["छाती", "chest"],
  ["दर्द", "pain"],
  ["सांस", "breathing"],
  ["तकलीफ", "difficulty"],
  ["बुखार", "fever"],
  ["खांसी", "cough"],
  ["खाँसी", "cough"],
  ["बच्चा", "child"],
  ["त्वचा", "skin"],
  ["खुजली", "itching"],
  ["पेट", "stomach"],
  ["आंख", "eye"],
  ["आँख", "eye"],
  ["ಜ್ವರ", "fever"],
  ["ಕೆಮ್ಮು", "cough"],
  ["ಮಗು", "child"],
  ["ಎದೆ", "chest"],
  ["ನೋವು", "pain"],
  ["ಚರ್ಮ", "skin"],
  ["ದದ್ದು", "rash"],
  ["ಕಣ್ಣು", "eye"],
  ["ಉಸಿರಾಟ", "breathing"],
  ["காய்ச்சல்", "fever"],
  ["இருமல்", "cough"],
  ["குழந்தை", "child"],
  ["மார்பு", "chest"],
  ["வலி", "pain"],
  ["கண்", "eye"],
  ["மங்கலான பார்வை", "blurred vision"],
  ["தோல்", "skin"],
  ["அரிப்பு", "itching"],
  ["జ్వరం", "fever"],
  ["దగ్గు", "cough"],
  ["పిల్ల", "child"],
  ["ఛాతి", "chest"],
  ["నొప్పి", "pain"],
  ["చర్మం", "skin"],
  ["దద్దుర్లు", "rash"],
  ["దురద", "itching"],
  ["కంటి", "eye"],
  ["శ్వాస", "breathing"]
];

export function normalizeText(text) {
  const folded = String(text || "")
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[^\p{L}\p{M}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();

  const translatedTerms = [];
  for (const [source, target] of localLanguageTerms) {
    if (folded.includes(source)) {
      translatedTerms.push(target);
    }
  }
  return `${folded} ${translatedTerms.join(" ")}`.replace(/\s+/g, " ").trim();
}

export function tokenize(text) {
  return normalizeText(text)
    .split(/\s+/)
    .filter((token) => token.length > 1 && !fillerWords.has(token));
}

function phraseCount(normalizedText, phrase) {
  const escaped = phrase.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const matches = normalizedText.match(new RegExp(`(^|\\s)${escaped}(?=\\s|$)`, "giu"));
  return matches ? matches.length : 0;
}

function scoreSpecialties(normalizedText) {
  const scores = Object.fromEntries(specialties.map((specialty) => [specialty.id, 0]));
  const matched = Object.fromEntries(specialties.map((specialty) => [specialty.id, []]));

  for (const [specialtyId, keywords] of Object.entries(specialtyKeywords)) {
    for (const [phrase, weight] of Object.entries(keywords)) {
      const count = phraseCount(normalizedText, phrase);
      if (count > 0) {
        scores[specialtyId] += weight * count;
        matched[specialtyId].push(phrase);
      }
    }
  }

  return { scores, matched };
}

export function assessUrgency(text) {
  const normalizedText = normalizeText(text);
  let score = 0;
  const reasons = [];

  for (const signal of urgentSignals) {
    if (phraseCount(normalizedText, signal.phrase) > 0) {
      score += signal.score;
      reasons.push(signal.reason);
    }
  }

  const tokens = new Set(tokenize(normalizedText));
  if (tokens.has("baby") || tokens.has("infant") || tokens.has("newborn") || tokens.has("child")) {
    if (tokens.has("fever") || tokens.has("breathing")) {
      score += 2;
      reasons.push("Child fever or breathing symptoms are prioritized.");
    }
  }

  if ((tokens.has("pregnant") || tokens.has("pregnancy")) && tokens.has("bleeding")) {
    score += 5;
    reasons.push("Bleeding during pregnancy is an urgent warning sign.");
  }

  if (score >= 7) {
    return {
      level: "emergency",
      score,
      label: "Emergency priority",
      recommendation: "Seek emergency care now if symptoms are current or worsening.",
      reasons: [...new Set(reasons)]
    };
  }

  if (score >= 4) {
    return {
      level: "urgent",
      score,
      label: "Urgent appointment",
      recommendation: "Book the earliest available slot and consider same-day evaluation.",
      reasons: [...new Set(reasons)]
    };
  }

  if (score >= 2) {
    return {
      level: "soon",
      score,
      label: "Priority appointment",
      recommendation: "A near-term appointment is recommended.",
      reasons: [...new Set(reasons)]
    };
  }

  return {
    level: "routine",
    score,
    label: "Routine appointment",
    recommendation: "Book a routine appointment with the recommended department.",
    reasons: [...new Set(reasons)]
  };
}

export function classifySymptoms(text) {
  const normalizedText = normalizeText(text);
  const { scores, matched } = scoreSpecialties(normalizedText);
  const ranked = Object.entries(scores)
    .map(([specialtyId, score]) => {
      const specialty = specialties.find((item) => item.id === specialtyId);
      return {
        specialtyId,
        specialtyName: specialty?.name || specialtyId,
        description: specialty?.description || "",
        score,
        matchedTerms: matched[specialtyId]
      };
    })
    .sort((a, b) => b.score - a.score || a.specialtyName.localeCompare(b.specialtyName));

  const best = ranked[0];
  const usefulScores = ranked.filter((item) => item.score > 0);
  const totalScore = usefulScores.reduce((sum, item) => sum + item.score, 0);
  const fallback = specialties.find((item) => item.id === "general-medicine");
  const urgency = assessUrgency(text);

  if (!best || best.score === 0) {
    return {
      specialtyId: fallback.id,
      specialtyName: fallback.name,
      description: fallback.description,
      confidence: 0.42,
      matchedTerms: [],
      alternatives: ranked.slice(0, 3),
      urgency,
      normalizedText
    };
  }

  const confidence = Math.min(0.98, Math.max(0.48, best.score / Math.max(totalScore, best.score)));

  return {
    specialtyId: best.specialtyId,
    specialtyName: best.specialtyName,
    description: best.description,
    confidence: Number(confidence.toFixed(2)),
    matchedTerms: best.matchedTerms,
    alternatives: ranked.filter((item) => item.specialtyId !== best.specialtyId).slice(0, 3),
    urgency,
    normalizedText
  };
}

export function evaluateClassifier(cases) {
  const rows = cases.map((testCase) => {
    const prediction = classifySymptoms(testCase.text);
    return {
      text: testCase.text,
      expected: testCase.expected,
      predicted: prediction.specialtyId,
      confidence: prediction.confidence,
      passed: prediction.specialtyId === testCase.expected
    };
  });

  const correct = rows.filter((row) => row.passed).length;
  return {
    total: rows.length,
    correct,
    accuracy: rows.length ? correct / rows.length : 0,
    rows
  };
}
