const memory = {
  appointments: [],
  manualSlots: []
};

function canUseLocalStorage() {
  try {
    return typeof window !== "undefined" && "localStorage" in window;
  } catch {
    return false;
  }
}

function readJson(key, fallback) {
  if (!canUseLocalStorage()) {
    return memory[key] ?? fallback;
  }
  const raw = window.localStorage.getItem(`mediguide:${key}`);
  if (!raw) {
    return fallback;
  }
  try {
    return JSON.parse(raw);
  } catch {
    return fallback;
  }
}

function writeJson(key, value) {
  memory[key] = value;
  if (canUseLocalStorage()) {
    window.localStorage.setItem(`mediguide:${key}`, JSON.stringify(value));
  }
}

export function loadState() {
  return {
    appointments: readJson("appointments", []),
    manualSlots: readJson("manualSlots", [])
  };
}

export function saveState(state) {
  writeJson("appointments", state.appointments || []);
  writeJson("manualSlots", state.manualSlots || []);
}

export function resetState() {
  writeJson("appointments", []);
  writeJson("manualSlots", []);
}
