import { doctors as defaultDoctors, specialties } from "./data.js";

const appointmentStatuses = new Set(["booked", "in-progress", "completed", "cancelled", "no-show"]);

export function addMinutes(date, minutes) {
  return new Date(date.getTime() + minutes * 60 * 1000);
}

export function formatDateTime(value, locale = "en-IN") {
  const date = value instanceof Date ? value : new Date(value);
  return new Intl.DateTimeFormat(locale, {
    dateStyle: "medium",
    timeStyle: "short"
  }).format(date);
}

export function getSpecialtyName(specialtyId) {
  return specialties.find((item) => item.id === specialtyId)?.name || specialtyId;
}

function makeSlotDate(dayOffset, time, baseDate) {
  const [hours, minutes] = time.split(":").map(Number);
  const date = new Date(baseDate);
  date.setHours(0, 0, 0, 0);
  date.setDate(date.getDate() + dayOffset);
  date.setHours(hours, minutes, 0, 0);
  return date;
}

export function generateDoctorSlots(doctor, options = {}) {
  const baseDate = options.baseDate ? new Date(options.baseDate) : new Date();
  const days = options.days ?? 7;
  const slots = [];
  for (let day = 0; day < days; day += 1) {
    for (const time of doctor.weeklySlots || []) {
      const slotDate = makeSlotDate(day, time, baseDate);
      if (slotDate > baseDate) {
        slots.push({
          id: `${doctor.id}-${slotDate.toISOString()}`,
          doctorId: doctor.id,
          doctorName: doctor.name,
          specialtyId: doctor.specialtyId,
          specialtyName: getSpecialtyName(doctor.specialtyId),
          startsAt: slotDate.toISOString(),
          consultationMinutes: doctor.consultationMinutes,
          rating: doctor.rating,
          qualityScore: doctor.qualityScore
        });
      }
    }
  }
  return slots;
}

export function buildSlotPool(doctors = defaultDoctors, appointments = [], options = {}) {
  const manualSlots = options.manualSlots || [];
  const generated = doctors.flatMap((doctor) => generateDoctorSlots(doctor, options));
  const manual = manualSlots.map((slot) => {
    const doctor = doctors.find((item) => item.id === slot.doctorId);
    return {
      id: slot.id,
      doctorId: slot.doctorId,
      doctorName: doctor?.name || "Doctor",
      specialtyId: doctor?.specialtyId || "general-medicine",
      specialtyName: getSpecialtyName(doctor?.specialtyId || "general-medicine"),
      startsAt: slot.startsAt,
      consultationMinutes: doctor?.consultationMinutes || 15,
      rating: doctor?.rating || 4.4,
      qualityScore: doctor?.qualityScore || 85
    };
  });

  const activeKeys = new Set(
    appointments
      .filter((appointment) => !["cancelled", "no-show"].includes(appointment.status))
      .map((appointment) => `${appointment.doctorId}-${appointment.startsAt}`)
  );

  return [...generated, ...manual]
    .filter((slot) => !activeKeys.has(`${slot.doctorId}-${slot.startsAt}`))
    .sort((a, b) => new Date(a.startsAt) - new Date(b.startsAt));
}

function urgencyWeight(level) {
  return {
    emergency: 38,
    urgent: 28,
    soon: 16,
    routine: 8
  }[level] || 8;
}

function scoreSlot(slot, specialtyId, urgencyLevel, now) {
  const startsAt = new Date(slot.startsAt);
  const hoursAway = Math.max(0, (startsAt - now) / 36e5);
  const specialtyMatch = slot.specialtyId === specialtyId ? 100 : 35;
  const earlyScore = Math.max(0, 44 - Math.min(44, hoursAway));
  const urgencyBoost = urgencyWeight(urgencyLevel) * (hoursAway <= 24 ? 1 : 0.55);
  const doctorQuality = slot.rating * 5 + slot.qualityScore / 5;
  return specialtyMatch + earlyScore + urgencyBoost + doctorQuality;
}

export function recommendSlots({ specialtyId, urgencyLevel = "routine", doctors = defaultDoctors, appointments = [], manualSlots = [], limit = 5, now = new Date() }) {
  const pool = buildSlotPool(doctors, appointments, { manualSlots, baseDate: now, days: 7 });
  return pool
    .map((slot) => ({
      ...slot,
      score: Number(scoreSlot(slot, specialtyId, urgencyLevel, now).toFixed(2))
    }))
    .sort((a, b) => b.score - a.score || new Date(a.startsAt) - new Date(b.startsAt))
    .slice(0, limit);
}

export function createAppointment({ patient, triage, slot, paymentStatus = "pending" }) {
  if (!patient?.name || !slot || !triage?.specialtyId) {
    throw new Error("Patient, triage result, and slot are required.");
  }

  return {
    id: `apt-${Date.now()}-${Math.random().toString(16).slice(2, 8)}`,
    patientName: patient.name.trim(),
    patientAge: Number(patient.age),
    patientPhone: patient.phone.trim(),
    symptoms: patient.symptoms.trim(),
    specialtyId: triage.specialtyId,
    specialtyName: triage.specialtyName,
    urgencyLevel: triage.urgency.level,
    urgencyLabel: triage.urgency.label,
    confidence: triage.confidence,
    matchedTerms: triage.matchedTerms,
    doctorId: slot.doctorId,
    doctorName: slot.doctorName,
    startsAt: slot.startsAt,
    consultationMinutes: slot.consultationMinutes,
    status: "booked",
    paymentStatus,
    paymentReference: "",
    createdAt: new Date().toISOString(),
    startedAt: "",
    completedAt: "",
    cancelledAt: ""
  };
}

export function updateAppointmentStatus(appointment, status, timestamp = new Date()) {
  if (!appointmentStatuses.has(status)) {
    throw new Error(`Unknown appointment status: ${status}`);
  }

  const updated = { ...appointment, status };
  if (status === "in-progress") {
    updated.startedAt = updated.startedAt || timestamp.toISOString();
  }
  if (status === "completed") {
    updated.completedAt = timestamp.toISOString();
  }
  if (status === "cancelled") {
    updated.cancelledAt = timestamp.toISOString();
  }
  return updated;
}

export function markPayment(appointment, method = "UPI", timestamp = new Date()) {
  return {
    ...appointment,
    paymentStatus: "paid",
    paymentMethod: method,
    paymentReference: `PAY-${timestamp.getFullYear()}${String(timestamp.getMonth() + 1).padStart(2, "0")}-${Math.random()
      .toString(36)
      .slice(2, 8)
      .toUpperCase()}`,
    paidAt: timestamp.toISOString()
  };
}

export function getDoctorQueue(doctorId, appointments, now = new Date()) {
  return appointments
    .filter((appointment) => appointment.doctorId === doctorId)
    .filter((appointment) => !["cancelled", "completed", "no-show"].includes(appointment.status))
    .sort((a, b) => {
      const urgencyRank = { emergency: 0, urgent: 1, soon: 2, routine: 3 };
      return (
        (urgencyRank[a.urgencyLevel] ?? 3) - (urgencyRank[b.urgencyLevel] ?? 3) ||
        new Date(a.startsAt) - new Date(b.startsAt) ||
        new Date(a.createdAt) - new Date(b.createdAt)
      );
    })
    .map((appointment, index, list) => {
      const prior = list.slice(0, index);
      const minutesBefore = prior.reduce((sum, item) => {
        if (item.status === "in-progress" && item.startedAt) {
          const elapsed = Math.max(0, (now - new Date(item.startedAt)) / 60000);
          return sum + Math.max(0, item.consultationMinutes - elapsed);
        }
        return sum + item.consultationMinutes;
      }, 0);
      const waitMinutes = Math.max(0, Math.round(minutesBefore));
      return {
        ...appointment,
        queuePosition: index + 1,
        estimatedWaitMinutes: waitMinutes,
        estimatedStartAt: addMinutes(now, waitMinutes).toISOString()
      };
    });
}

export function getDoctorMetrics(doctorId, appointments, now = new Date()) {
  const queue = getDoctorQueue(doctorId, appointments, now);
  const doctorAppointments = appointments.filter((appointment) => appointment.doctorId === doctorId);
  const completed = doctorAppointments.filter((appointment) => appointment.status === "completed");
  const paid = doctorAppointments.filter((appointment) => appointment.paymentStatus === "paid");
  const totalConsultationMinutes = completed.reduce((sum, appointment) => {
    if (appointment.startedAt && appointment.completedAt) {
      return sum + Math.max(1, Math.round((new Date(appointment.completedAt) - new Date(appointment.startedAt)) / 60000));
    }
    return sum + appointment.consultationMinutes;
  }, 0);

  return {
    queueCount: queue.length,
    urgentCount: queue.filter((appointment) => ["emergency", "urgent"].includes(appointment.urgencyLevel)).length,
    paidCount: paid.length,
    averageConsultMinutes: completed.length ? Math.round(totalConsultationMinutes / completed.length) : 0
  };
}
