const SpeechRecognition = globalThis.SpeechRecognition || globalThis.webkitSpeechRecognition;

export function isVoiceSupported() {
  return Boolean(SpeechRecognition);
}

export function createVoiceInput({ language = "en-IN", onResult, onError, onStateChange }) {
  if (!SpeechRecognition) {
    return {
      supported: false,
      start() {
        onError?.("Voice input is not supported in this browser. Type the symptoms instead.");
      },
      stop() {}
    };
  }

  const recognition = new SpeechRecognition();
  recognition.lang = language;
  recognition.interimResults = false;
  recognition.maxAlternatives = 1;

  recognition.onstart = () => onStateChange?.("listening");
  recognition.onend = () => onStateChange?.("idle");
  recognition.onerror = (event) => onError?.(event.error || "Voice input failed.");
  recognition.onresult = (event) => {
    const transcript = event.results?.[0]?.[0]?.transcript || "";
    onResult?.(transcript);
  };

  return {
    supported: true,
    start(nextLanguage) {
      recognition.lang = nextLanguage || language;
      recognition.start();
    },
    stop() {
      recognition.stop();
    }
  };
}
