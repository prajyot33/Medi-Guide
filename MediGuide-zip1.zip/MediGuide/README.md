# MediGuide

MediGuide is an AI-assisted doctor appointment and triage prototype for the IIT Dharwad Summer of Innovation problem statement. It predicts the most relevant medical specialty from patient symptoms, ranks appointment slots, supports browser voice input for local-language queries, and includes a doctor portal for queue management.

## Features

- Symptom-to-specialty prediction with explainable NLP keyword scoring.
- Urgency detection for red-flag symptoms and smart slot prioritization.
- Conversational patient intake with typed or browser voice input.
- Local-language support for common Hindi, Kannada, Tamil, and Telugu symptom terms.
- Appointment booking with doctor quality, specialization, rating, and availability.
- Mock payment confirmation linked to booked appointments.
- Appointment cancellation and released-slot handling.
- Doctor portal to view patients, add slots, track queue order, mark consultation status, and estimate waits.
- Built-in evaluation screen plus CLI evaluation command.

## Run Locally

```bash
npm start
```

Open `http://localhost:5173`.

## Test And Evaluate

```bash
npm test
npm run evaluate
```

The test suite covers specialty prediction, local-language term handling, urgency scoring, slot recommendations, duplicate booking prevention, payment updates, and queue estimates.

## Project Structure

- `index.html` and `styles.css`: web app shell and responsive UI.
- `src/data.js`: specialty, doctor, keyword, urgency, and evaluation data.
- `src/nlp.js`: symptom normalization, local-language expansion, classifier, urgency scorer, evaluation helper.
- `src/scheduler.js`: slot generation, smart ranking, appointment lifecycle, payments, queue estimates.
- `src/store.js`: localStorage persistence with a memory fallback.
- `src/voice.js`: Web Speech API voice-input plugin.
- `src/app.js`: patient chat, booking, payments, doctor portal, and evaluation screen.
- `docs/technical-report.md`: concise technical document for submission.

## Demo Flow

1. Open the Patient tab and enter symptoms or select a sample.
2. Review the predicted department, urgency label, confidence, and matched symptoms.
3. Enter patient details and book a recommended slot.
4. Pay using the mock payment button or cancel the appointment.
5. Open Doctor Portal to manage queue status and consultation lifecycle.
6. Open Evaluation to review model accuracy on sample cases.
