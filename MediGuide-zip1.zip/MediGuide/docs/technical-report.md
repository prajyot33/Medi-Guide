# MediGuide Technical Report

## 1. System Architecture

MediGuide is a browser-based prototype with modular JavaScript. The patient interface collects symptoms through text or browser voice input, the NLP module predicts a specialty and urgency level, and the scheduler ranks available doctor slots. Appointment, payment, and queue state are persisted in `localStorage` so the demo survives refreshes.

Main modules:

- `src/nlp.js`: symptom normalization, local-language term expansion, specialty scoring, urgency assessment, and evaluation.
- `src/scheduler.js`: doctor slot generation, ranked recommendations, appointment lifecycle, payment markers, queue order, and wait-time estimates.
- `src/app.js`: conversational interface, booking flow, doctor portal, queue controls, and evaluation UI.
- `src/data.js`: mock doctors, specialties, keyword weights, urgent symptom signals, and evaluation cases.

## 2. Symptom Classification Method

The current prototype uses an explainable NLP scoring model. Patient text is normalized by lowercasing, removing punctuation, folding diacritics, and expanding common local-language symptom terms from Hindi, Kannada, Tamil, and Telugu into English medical concepts. Each specialty has a weighted keyword and phrase dictionary. The classifier sums matched weights by specialty and selects the highest score.

The output includes:

- Predicted specialty and department description.
- Confidence score based on the winning score relative to total matched evidence.
- Matched symptom terms for explainability.
- Alternate departments when secondary evidence is found.
- Urgency level from separate red-flag symptom scoring.

This approach is deterministic, fast, and transparent. It is suitable for a prototype and can later be replaced by a trained transformer or clinical intent model using the same app contract.

## 3. Scheduling Logic

Doctors are modeled with specialty, rating, quality score, languages, consultation duration, and weekly availability. The scheduler generates future slots, removes slots already occupied by active appointments, and scores the remaining options.

Slot score considers:

- Specialty match.
- Earliest available time.
- Urgency level.
- Doctor rating.
- Doctor quality score.

The doctor portal computes queue order by urgency first, then slot time, then booking time. Waiting time is estimated from active consultations and the remaining consultation duration of patients ahead in the queue.

## 4. Additional Features

The implementation includes the requested portal features:

- Patient conversational interface.
- Browser voice input plugin with selectable local language.
- Appointment booking and cancellation.
- Mock payment confirmation with reference number.
- Doctor portal to view scheduled patients.
- Slot creation by doctor.
- Live queue refresh and automatic wait-time updates.
- Consultation lifecycle: start, finish, no-show, and cancel.
- Evaluation screen for specialty prediction accuracy.

## 5. Experimental Setup And Evaluation

Evaluation uses 16 representative symptom queries across cardiology, dermatology, orthopedics, neurology, pulmonology, gastroenterology, ENT, ophthalmology, pediatrics, psychiatry, gynecology, and general medicine. It includes English and local-language examples.

Run:

```bash
npm test
npm run evaluate
```

The bundled cases currently pass at 100% accuracy. This is a prototype metric on a small curated dataset, not a clinical validation result.

## 6. Limitations And Improvements

MediGuide does not provide medical diagnosis and should not be used as a replacement for emergency care or clinician judgment. The keyword model can miss unusual phrasing, mixed symptoms, spelling mistakes, and rare diseases. The mock payment service is not connected to a real provider.

Recommended next steps:

- Train a supervised model on larger symptom-to-specialty datasets.
- Add spell correction and richer multilingual medical terminology.
- Add authentication for patients and doctors.
- Connect to a real hospital scheduling backend.
- Integrate a real payment provider in sandbox mode.
- Add audit logs, consent, privacy controls, and clinical safety review.
