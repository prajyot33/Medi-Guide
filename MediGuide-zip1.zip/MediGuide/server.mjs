import { createServer } from "node:http";
import { extname, join, normalize, resolve } from "node:path";
import { readFile } from "node:fs/promises";

const root = process.cwd();
const port = Number(process.env.PORT || 5173);

const types = {
  ".css": "text/css; charset=utf-8",
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".md": "text/markdown; charset=utf-8",
  ".png": "image/png"
};

function resolvePath(urlPath) {
  const cleanPath = urlPath.split("?")[0] === "/" ? "/index.html" : urlPath.split("?")[0];
  const target = normalize(join(root, cleanPath));
  if (!target.startsWith(root)) {
    return null;
  }
  return target;
}

createServer(async (request, response) => {
  const filePath = resolvePath(decodeURIComponent(request.url || "/"));
  if (!filePath) {
    response.writeHead(403);
    response.end("Forbidden");
    return;
  }

  try {
    const body = await readFile(resolve(filePath));
    response.writeHead(200, {
      "Content-Type": types[extname(filePath)] || "application/octet-stream"
    });
    response.end(body);
  } catch {
    response.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
    response.end("Not found");
  }
}).listen(port, () => {
  console.log(`MediGuide running at http://localhost:${port}`);
});
