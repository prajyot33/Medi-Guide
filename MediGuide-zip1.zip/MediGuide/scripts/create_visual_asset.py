from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "clinical-workspace.png"


def rounded(draw, box, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def main():
    OUT.parent.mkdir(parents=True, exist_ok=True)
    width, height = 1280, 720
    image = Image.new("RGB", (width, height), "#e8f3f0")
    draw = ImageDraw.Draw(image)

    # Background bands
    draw.rectangle((0, 0, width, 190), fill="#d7ebe8")
    draw.rectangle((0, 560, width, height), fill="#dfe9ee")
    draw.ellipse((-180, 80, 340, 520), fill="#cce8e1")
    draw.ellipse((920, -120, 1450, 360), fill="#f4d9ce")

    # Desk
    rounded(draw, (110, 410, 1170, 625), 36, "#ffffff", "#c6d7dc", 3)
    draw.rectangle((145, 500, 1135, 625), fill="#f7faf9")
    draw.line((145, 500, 1135, 500), fill="#d6e1e5", width=3)

    # Main dashboard screen
    rounded(draw, (365, 105, 915, 470), 24, "#1f3147", "#18263a", 4)
    rounded(draw, (390, 130, 890, 445), 18, "#f8fbfb")
    rounded(draw, (420, 160, 610, 205), 12, "#007c78")
    rounded(draw, (635, 160, 860, 205), 12, "#eef4f5", "#d8e2e6", 2)
    for index, color in enumerate(["#d8644a", "#007c78", "#356db0", "#a87915"]):
        x = 420 + index * 110
        rounded(draw, (x, 235, x + 82, 330), 14, color)
        draw.ellipse((x + 27, 258, x + 55, 286), fill="#ffffff")
        draw.rectangle((x + 18, 298, x + 64, 306), fill="#ffffff")
    for y in [355, 382, 409]:
        rounded(draw, (420, y, 860, y + 14), 7, "#e7eff2")
        rounded(draw, (420, y, 560 + (y - 355) * 2, y + 14), 7, "#79bbb7")

    # Doctor figure
    draw.ellipse((165, 150, 285, 270), fill="#7b4b3a")
    draw.ellipse((185, 170, 265, 255), fill="#f0b89e")
    rounded(draw, (145, 265, 310, 485), 36, "#ffffff", "#c8d7dd", 3)
    draw.polygon([(145, 300), (226, 392), (310, 300), (310, 485), (145, 485)], fill="#f6fbfb")
    draw.line((226, 392, 226, 485), fill="#d5e1e4", width=4)
    draw.ellipse((208, 382, 244, 418), outline="#007c78", width=5)
    draw.line((226, 418, 226, 445), fill="#007c78", width=4)
    draw.line((160, 330, 110, 410), fill="#f0b89e", width=20)
    draw.line((294, 330, 360, 410), fill="#f0b89e", width=20)

    # Patient cards / queue tablets
    for i, (x, y, color) in enumerate([(965, 160, "#ffffff"), (1000, 255, "#fff7f2"), (945, 350, "#ffffff")]):
        rounded(draw, (x, y, x + 190, y + 74), 18, color, "#cad9de", 3)
        draw.ellipse((x + 18, y + 18, x + 52, y + 52), fill=["#007c78", "#d8644a", "#356db0"][i])
        draw.rectangle((x + 68, y + 22, x + 156, y + 31), fill="#d6e1e5")
        draw.rectangle((x + 68, y + 43, x + 132, y + 52), fill="#d6e1e5")

    # Calendar and payment shapes on desk
    rounded(draw, (420, 440, 610, 590), 20, "#ffffff", "#cbd9de", 3)
    draw.rectangle((420, 440, 610, 478), fill="#d8644a")
    for row in range(3):
        for col in range(4):
            x = 443 + col * 39
            y = 500 + row * 25
            draw.rectangle((x, y, x + 18, y + 12), fill="#dfeaed")

    rounded(draw, (690, 475, 905, 575), 20, "#20324a")
    draw.ellipse((723, 500, 763, 540), fill="#007c78")
    draw.ellipse((750, 500, 790, 540), fill="#d8644a")
    draw.rectangle((815, 506, 875, 518), fill="#d6e1e5")
    draw.rectangle((815, 532, 860, 544), fill="#d6e1e5")

    # Plant / calm clinic detail
    draw.rectangle((1000, 470, 1075, 585), fill="#a87915")
    draw.polygon([(1038, 470), (990, 385), (1030, 440)], fill="#2f8a62")
    draw.polygon([(1038, 470), (1088, 382), (1060, 445)], fill="#5fae80")
    draw.polygon([(1038, 470), (1020, 360), (1058, 438)], fill="#2f8a62")

    image.save(OUT, "PNG", optimize=True)
    print(OUT)


if __name__ == "__main__":
    main()
