import { evaluationCases } from "../src/data.js";
import { evaluateClassifier } from "../src/nlp.js";

const evaluation = evaluateClassifier(evaluationCases);

console.log(`Specialty prediction accuracy: ${(evaluation.accuracy * 100).toFixed(1)}%`);
console.log(`Correct: ${evaluation.correct}/${evaluation.total}`);
console.table(
  evaluation.rows.map((row) => ({
    expected: row.expected,
    predicted: row.predicted,
    confidence: `${Math.round(row.confidence * 100)}%`,
    result: row.passed ? "pass" : "review",
    query: row.text
  }))
);
